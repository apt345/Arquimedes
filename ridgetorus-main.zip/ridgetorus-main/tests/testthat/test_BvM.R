
set.seed(12312)
n <- 500
mu1 <- c(-pi, 1)
kappa1 <- c(2, 1, 0)
mu2 <- c(1, 2)
kappa2 <- c(3:1)
mu3 <- c(0, 0)
kappa3 <- c(3, 1, 5)
samp1 <- r_bvm(n = n, mu1 = mu1[1], mu2 = mu1[2],
               k1 = kappa1[1], k2 = kappa1[2], lambda = kappa1[3])
samp2 <- r_bvm(n = n, mu1 = mu2[1], mu2 = mu2[2],
               k1 = kappa2[1], k2 = kappa2[2], lambda = kappa2[3])
samp3 <- r_bvm(n = n, mu1 = mu3[1], mu2 = mu3[2],
               k1 = kappa3[1], k2 = kappa3[2], lambda = kappa3[3])

test_that("Integrates one", {

  expect_equal(
    sdetorus::mcTorusIntegrate(f = d_bvm, mu = c(1, 2), kappa = 3:1,
                               p = 2, M = 1e5), 1, tolerance = 0.01)
  expect_equal(
    sdetorus::mcTorusIntegrate(f = d_bvm, mu = c(1, 2), kappa = c(50, 1, 2),
                               p = 2, M = 1e5), 1, tolerance = 0.01)

})

# test_that("Recover true parameters via MM", {
#
#   fit1 <- fit_bvm_mm(samp1)
#   fit2 <- fit_bvm_mm(samp2)
#   expect_equal(unname(unlist(fit1))[3:5], kappa1, tolerance = 0.2)
#   expect_equal(torus_dist(x=fit1$mu1, y = mu1[1]), 0, tolerance = 0.2)
#   expect_equal(torus_dist(x=fit1$mu2, y = mu1[2]), 0, tolerance = 0.2)
#
#   expect_equal(unname(unlist(fit2))[3:5], kappa2, tolerance = 0.2)
#   expect_equal(torus_dist(x=fit2$mu1, y = mu2[1]), 0, tolerance = 0.2)
#   expect_equal(torus_dist(x=fit2$mu2, y = mu2[2]), 0, tolerance = 0.2)
#
# })

test_that("Recover true parameters via MLE", {

  fit1 <- fit_bvm_mle(samp1)[1:5]
  fit2 <- fit_bvm_mle(samp2)[1:5]
  fit3 <- fit_bvm_mle(samp3, initial_values = c(mu3, kappa3))[1:5] # Cheating

  expect_equal(c(unname(torus_dist(x = fit1$mu1, y = mu1[1])),
                 unname(torus_dist(x = fit1$mu2, y = mu1[2])),
                 unname(unlist(fit1))[3:5] - kappa1), rep(0, 5),
               tolerance = 0.2)
  expect_equal(c(unname(torus_dist(x = fit2$mu1, y = mu2[1])),
                 unname(torus_dist(x = fit2$mu2, y = mu2[2])),
                 unname(unlist(fit2))[3:5] - kappa2), rep(0, 5),
               tolerance = 0.2)
  expect_equal(c(unname(torus_dist(x = fit3$mu1, y = mu3[1])),
                 unname(torus_dist(x = fit3$mu2, y = mu3[2])),
                 unname(unlist(fit3))[3:5] - kappa3), rep(0, 5),
               tolerance = 0.2)

})
