
ridge <- ridge_bvm(mu1 = 0, mu2 = 0, k1 = 0.3, k2 = 1, lambda = 1.2,
                   subintervals_1 = 1000, subintervals_2 = 1000)
coef <- ridge_fourier_fit(ridge)
R_star <- function(phi, coef){
  s <- 0
  for (i in 1:length(coef)) {
    s <- s + coef[i] * sin(i * phi)
  }
  return(s)
}
val <- R_star(phi = ridge[,1], coef = coef)

test_that("The fit reproduces the ridge" ,{

  expect_equal(ridge[,2] - val, rep(0, length(val)) , tolerance = 0.1)

})


# # Something is off
# data("santabarbara")
# fit_AB <- ridge_pca(x = santabarbara[c("A", "B")], type = "bwc", N = 1e3)
# fit_BA <- ridge_pca(x = santabarbara[c("B", "A")], type = "bwc", N = 1e3)
# show_ridge_pca(fit_AB)
# torus_pairs(fit_AB$scores)
# show_ridge_pca(fit_BA)
# torus_pairs(fit_BA$scores)
# fit_AB$b_hat[1:10]
# fit_BA$b_hat[1:10]
