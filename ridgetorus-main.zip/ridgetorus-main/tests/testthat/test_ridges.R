mu1 <- c(-pi, 1)
kappa1 <- c(0.3, 1, 0.2)
mu2 <- c(1, 2)
kappa2 <- c(0.4, 0.1, 0.8)
ridge1 <- ridge_bvm(mu1 = mu1[1], mu2 = mu1[2], k1 = kappa1[1], k2 = kappa1[2],
                    lambda = kappa1[3], subintervals_1 = 1000,
                    subintervals_2 = 1000)
ridge2 <- ridge_bvm(mu1 = mu2[1], mu2 = mu2[2], k1 = kappa2[1], k2 = kappa2[2],
                    lambda = kappa2[3], subintervals_1 = 1000,
                    subintervals_2 = 1000)
val1 <- apply(sdetorus::toPiInt(t(t(ridge1) - mu1)), 1,
              function(x) implicit_bvm(theta2 = x[2], theta1 = x[1],
                                       kappa = kappa1))
val2 <- apply(sdetorus::toPiInt(t(t(ridge2) - mu2)), 1,
              function(x) implicit_bvm(theta2 = x[2], theta1 = x[1],
                                       kappa = kappa2))

test_that("Implicit is 0", {

  expect_equal(val1, rep(0, length(ridge1[, 1])), tolerance = 0.01)
  expect_equal(val2, rep(0, length(ridge2[, 1])), tolerance = 0.01)

})

# # Errors on limit cases:
# solved
# ridge_bwc(xi1 = 0.5, xi2 = 0.5, rho = 0.5,
#           subintervals_1 = 1e3,
#           subintervals_2 = 1e3)

# las xi estan contenidas en -1, 1 y lo demas ha sido porque en los casos con
# distribucion estrecha hay que coger mas subintervalos o no detecta la curva
# si eso sucede, cuando el algoritmo de filtrado empieza en 0,0, no ve punto cercano
# y solo devuelve el 0,0

# ridge_bwc(xi1 = 0.1, xi2 = 0.99, rho = 0.99,
#           subintervals_1 = 1e4,
#           subintervals_2 = 1e4)

# ridge_bwc(xi1 = 0.1, xi2 = 0.99, rho = 0.1,
#           subintervals_1 = 1e4,
#           subintervals_2 = 1e4)

# 
# # Issues on limit cases:
# plot(ridge_bwc(xi1 = 0.1, xi2 = 0.5, rho = 0,
#           subintervals_1 = 1e3,
#           subintervals_2 = 1e3))
# plot(ridge_bwc(xi1 = 0.1, xi2 = 0.5, rho = 0.99,
#           subintervals_1 = 1e3,
#           subintervals_2 = 1e3))

