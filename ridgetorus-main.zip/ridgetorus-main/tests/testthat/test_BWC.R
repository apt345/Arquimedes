set.seed(12315)
n <- 500
mu1 <- c(-pi, 1)
xi1 <- c(0.4, 0.7, 0)
mu2 <- c(1, 2)
xi2 <- c(0.5, 0.2, 0.4)
mu3 <- c(0, 0)
xi3 <- c(0, 0.6, 0.8)
samp1 <- r_bwc(n = n, mu1 = mu1[1], mu2 = mu1[2], xi1 = xi1[1], xi2 = xi1[2],
               rho = xi1[3])
samp2 <- r_bwc(n = n, mu1 = mu2[1], mu2 = mu2[2], xi1 = xi2[1], xi2 = xi2[2],
               rho = xi2[3])
samp3 <- r_bwc(n = n, mu1 = mu3[1], mu2 = mu3[2], xi1 = xi3[1], xi2 = xi3[2],
               rho = xi3[3])

test_that("Integrates one", {

  expect_equal(
    sdetorus::mcTorusIntegrate(f = d_bwc, mu1 = mu1[1], mu2 = mu1[2],
                               xi1 = xi1[1], xi2 = xi1[2], rho = xi1[3],
                               p = 2, M = 1e5), 1, tolerance = 0.01)
  expect_equal(
    sdetorus::mcTorusIntegrate(f = d_bwc, mu1 = mu2[1], mu2 = mu2[2],
                               xi1 = xi2[1], xi2 = xi2[2], rho = xi2[3],
                               p = 2, M = 1e5), 1, tolerance = 0.01)

})

test_that("Recover true parameters via MM", {

  fit1 <- fit_bwc_mm(samp1)
  fit2 <- fit_bwc_mm(samp2)
  fit3 <- fit_bwc_mm(samp3)

  expect_equal(c(unname(torus_dist(x = fit1$mu1, y = mu1[1])),
                 unname(torus_dist(x = fit1$mu2, y = mu1[2])),
                 unname(unlist(fit1))[3:5] - xi1), rep(0, 5),
               tolerance = 0.2)
  expect_equal(c(unname(torus_dist(x = fit2$mu1, y = mu2[1])),
                 unname(torus_dist(x = fit2$mu2, y = mu2[2])),
                 unname(unlist(fit2))[3:5] - xi2), rep(0, 5),
               tolerance = 0.2)
  expect_equal(c(unname(torus_dist(x = fit3$mu1, y = mu3[1])),
                 unname(torus_dist(x = fit3$mu2, y = mu3[2])),
                 unname(unlist(fit3))[3:5] - xi3), rep(0, 5),
               tolerance = 0.2)

})

test_that("Recover true parameters via MLE", {

  fit1 <- fit_bwc_mle(samp1)[1:5]
  fit2 <- fit_bwc_mle(samp2)[1:5]
  fit3 <- fit_bwc_mle(samp3)[1:5]

  expect_equal(c(unname(torus_dist(x = fit1$mu1, y = mu1[1])),
                 unname(torus_dist(x = fit1$mu2, y = mu1[2])),
                 unname(unlist(fit1))[3:5] - xi1), rep(0, 5),
               tolerance = 0.2)
  expect_equal(c(unname(torus_dist(x = fit2$mu1, y = mu2[1])),
                 unname(torus_dist(x = fit2$mu2, y = mu2[2])),
                 unname(unlist(fit2))[3:5] - xi2), rep(0, 5),
               tolerance = 0.2)
  expect_equal(c(unname(torus_dist(x = fit3$mu1, y = mu3[1])),
                 unname(torus_dist(x = fit3$mu2, y = mu3[2])),
                 unname(unlist(fit3))[3:5] - xi3), rep(0, 5),
               tolerance = 0.2)

})
