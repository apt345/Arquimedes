library(testthat)
library(ridgetorus)

test_check("ridgetorus")
