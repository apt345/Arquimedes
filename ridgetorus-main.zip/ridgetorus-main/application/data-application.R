
# This script reproduces all the figures and analyses of the application of
# toroidal PCA via density ridges onto the Santa Barbara dataset.

# Required packages
library(ridgetorus)
library(ks)
library(latex2exp)
library(animation)
library(ggmap)
library(ggimage)
library(BBmisc)

# Load data
data("santabarbara")

# Kernel density estimation
kernel_density <- function(theta, loc) {

  n <- ncol(theta)
  for (t in 1:(n - 1)) {

    for (w in (t + 1):n) {

      # Select the given pair of data
      x <- theta[, c(t, w)]

      # Compute kde for a diagonal bandwidth matrix (trivially positive definite)
      Hns <- ks::Hns(x = x)

      # Expand the grid to account for periodicity
      expanded_x <- 0
      for (i in c(-1, 0, 1)) {

        for (j in c(-1, 0, 1)) {

          expanded_x <- rbind(expanded_x, cbind(x[, 1] + i * 2 * pi ,
                                                x[, 2] + j * 2 * pi))

        }
      }
      expanded_x <- expanded_x[-1,]

      # Compute the kde
      kde <- ks::kde(x = expanded_x, H = Hns, gridsize = c(400, 400),
                     xmin = c(-3 * pi, -3 * pi), xmax = c(3 * pi, 3 * pi))

      # Plot the kde and save it into a file
      colorBreaks <- c(seq(0, 3 / pi^2, l = 21), 0.8, 1.4, 2)
      png(paste("kde", loc[t],"_", loc[w], ".PNG", sep = ""))
      image(kde$eval.points[[1]], kde$eval.points[[2]], 9 * kde$estimate,
            col = viridis::viridis(23), xlab = TeX(paste("$\\theta_", loc[t],
                                                         sep = "")),
            ylab = TeX(paste("$\\theta_", loc[w], sep = "")), xlim = c(-pi, pi), 
            ylim = c(-pi, pi), cex.lab = 1.25, axes = FALSE,
            breaks = colorBreaks)
      at <- seq(-pi, pi, l = 5)
      labels <- c("W", "S","E","N", "W")
      axis(1, at = at, labels = labels)
      axis(2, at = at, labels = labels)
      points(x)
      dev.off()
      
    }
  }
}

# Reproduce kde plots for analyses AB, BC, AC, BD
kernel_density(theta = santabarbara[c("A","B","C")], loc = c("A", "B", "C"))
kernel_density(theta = santabarbara[c("B", "D")], loc = c("B", "D"))

# Bivariate von Mises plots

von_mises <- function(theta, loc) {
  n <- ncol(theta)
  for (t in 1:(n - 1)) {

    for (w in (t + 1):n) {

      # Select the given pair of data and their name
      x <- theta[, c(t, w)]
      loc_x <- loc[c(t, w)]

      # Obtain the parameters of the von Mises distribution via ML
      param <- fit_bvm_mle(theta = x)
      mu <- c(param$mu1, param$mu2)
      k <- c(param$k1, param$k2)
      lambda <- param$lambda

      # Index by the lowest kappa variable for the ridge to be horizontal
      index <- order(k)
      x <- x[, index]
      k <- k[index]
      mu <- mu[index]
      loc_x <- loc_x[index]

      # Print the parameters and the minus loglikelihood
      print(loc_x)
      print(mu)
      print(k)
      print(lambda)
      loglikelihood <- sum(log(d_bvm(x = x, mu = mu, kappa = c(k, 2 * lambda))))
      print(-loglikelihood)

      # Calculate density values and density ridge
      x1 <- seq( -pi, pi, l  =  200)
      y1 <- seq( -pi, pi, l  =  200)
      est <- apply(X = as.matrix(expand.grid(x1, y1)), 1, FUN = d_bvm,
                  mu = mu, kappa = c(k, 2 * lambda))
      densityvalues <- matrix(est, nrow = 200, ncol = 200, byrow = FALSE)
      ridge <- ridge_bvm(mu1 = mu[1], mu2 = mu[2], k1 = k[1], k2 = k[2],
                         lambda = lambda, subintervals_1 = 1000,
                         subintervals_2 = 1000)

      # Plot the results and save the image in a file
      colorBreaks <- c(seq(0, 3 / pi^2, l = 21), 0.8, 1.4, 2)
      png(paste("vonMises", loc_x[1], "_", loc_x[2], ".PNG", sep = ""))
      image(x1, y1, densityvalues, col = viridis::viridis(23), xlab = loc_x[1],
            ylab = loc_x[2], cex.lab = 1.25, axes = FALSE, breaks = colorBreaks)
      at <- seq(-pi, pi, l = 5)
      labels <- c("W", "S","E","N", "W")
      axis(1, at = at, labels = labels)
      axis(2, at = at, labels = labels)
      points(ridge, col = "red")
      points(x, col = "black")
      dev.off()
    }

  }

}

# Reproduce von Mises plots for analyses AB, BC, AC, BD
von_mises(theta = santabarbara[c("A","B","C")], loc = c("A", "B", "C"))
von_mises(theta = santabarbara[c("B", "D")], loc = c("B", "D"))

# Bivariate wrapped Cauchy plots
wrapped_cauchy <- function(theta, loc) {

  n <- ncol(theta)
  for (t in 1:(n - 1)) {

    for (w in (t + 1):n) {

      # Select the given pair of data and their name
      x <- theta[, c(t, w)]
      loc_x <- loc[c(t, w)]

      # Obtain the parameters of the wrapped Cauchy distribution via ML
      param <- fit_bwc_mle(theta = x)
      mu <- c(param$mu1, param$mu2)
      xi <- c(param$xi1, param$xi2)
      rho <- param$rho

      # Index by the lowest xi variable for the ridge to be horizontal
      index <- order(xi)
      x <- x[, index]
      xi <- xi[index]
      mu <- mu[index]
      loc_x <- loc_x[index]

      # Print the parameters and the minus log likelihood
      print(loc_x)
      print(mu)
      print(xi)
      print(rho)
      loglikelihood <- sum(log(d_bwc(theta = x, mu1 = mu[1], mu2 = mu[2],
                                     xi1 = xi[1], xi2 = xi[2], rho = rho)))
      print(-loglikelihood)

      # Calculate density values and density ridge
      x1 <- seq(-pi, pi, l = 200)
      y1 <- seq(-pi, pi, l = 200)
      est <- apply(X = as.matrix(expand.grid(x1, y1)), 1, FUN = d_bwc,
                  mu1 = mu[1], mu2 = mu[2], xi1 = xi[1], xi2 = xi[2], rho = rho)
      densityvalues <- matrix(est, nrow = 200, ncol = 200, byrow = FALSE)
      ridge <- ridge_bwc(mu1 = mu[1], mu2 = mu[2], xi1 = xi[1], xi2 = xi[2],
                         rho = rho, subintervals_1 = 1000,
                         subintervals_2 = 1000)

      # Plot the results and save it into a file
      colorBreaks <- c(seq(0, 3 / pi^2, l = 21), 0.8, 1.4, 2)
      png(paste("wrappedCauchy", loc_x[1],"_", loc_x[2],".PNG", sep = ""))
      image(x1, y1, densityvalues, col = viridis::viridis(23), xlab = loc_x[1],
            ylab = loc_x[2], cex.lab = 1.25, axes = FALSE, breaks = colorBreaks)
      at <- seq(-pi, pi, l = 5)
      labels <- c("W", "S","E","N", "W")
      axis(1, at = at, labels = labels)
      axis(2, at = at, labels = labels)
      points(ridge, col = "red")
      points(x, col = "black")
      dev.off()
    }

  }

}

# Reproduce wrapped Cauchy plots for analyses AB, BC, AC, BD
wrapped_cauchy(theta = santabarbara[c("A","B","C")], loc = c("A", "B", "C"))
wrapped_cauchy(theta = santabarbara[c("B", "D")], loc = c("B", "D"))

## Analysis for zone B-C and A-C

# Arc length of zone B-C
mu1 <- 0.93
mu2 <- -2.40
k1 <- 0.26
k2 <- 1.69
lambda <- -1.20
ridgeBC <- ridge_bvm(k1 = k1, k2 = k2, lambda = lambda, subintervals_1 = 10000,
                      subintervals_2 = 1000)

coef <- ridge_fourier_fit(ridgeBC)
gausslengedre_fit <- function(theta1, coef){

  n <- length(coef)
  s <- 0
  for (i in 1:n) {

    s <- s + coef[i] * sin(i * theta1)
  }

  return(s)

}

gausslengedre_fit_der <- function(theta1, coef){

  n <- length(coef)
  s <- 0
  for (i in 1:n) {

    s <- s + i * coef[i] * cos(i * theta1)
  }

  return(s)

}


# Integrand of the arc length function
integrand <- function(theta1){
  sqrt(1 + gausslengedre_fit_der(theta1, coef)^2)
}

s_mod <- function(t, t0){

  # Intervals of length 0.1
  return(integrate(f = integrand, lower = t0, upper = t)$value - 0.1)

}


arc_length <- function(){
  i <- 2
  t <- c(-pi)
  while (t[i - 1] < pi) {

    if (sign(s_mod(t = t[i - 1], t0 = t[i - 1])) !=
        sign(s_mod(t = pi, t0 = t[i - 1]))) {

      t <- append(t, uniroot(s_mod, t0 = t[i - 1],
                             interval = c(t[i - 1], pi))$root)
      i <- i + 1

    } else {

      break

    }

  }

  return(t)

}


th1_arc <- arc_length()
th2_arc <- gausslengedre_fit(th1_arc, coef)

# Associate transparency to the arrows according to the density
trans <- d_bvm(cbind(th1_arc, th2_arc), mu = c(mu1, mu2),
                     kappa = c(k1, k2, 2 * lambda))
trans <- trans / max(trans)

# Arrow for the angle of the marine current at each zone A or zone B
arr_1 <- data.frame(u = cos(sdetorus::toPiInt(th1_arc + mu1)),
                      v = sin(sdetorus::toPiInt(th1_arc + mu1)))
arr_2 <- data.frame(u = cos(sdetorus::toPiInt(th2_arc + mu2)),
                      v = sin(sdetorus::toPiInt(th2_arc + mu2)))

# Ridge image AB
d <- data.frame(x = -120.465, y = 34.35,
               image = "ridgetorus/application/ridgenoaxis.PNG")

# Coordinates of the ridge in the miniplot. Image is 0.45 wide and 0.2 high
theta_miniplot <- as.data.frame(cbind(sdetorus::toPiInt(th1_arc + mu1) * 
                                        0.45 / pi - 120.465,
                                     sdetorus::toPiInt(th2_arc + mu2) * 
                                       0.2 / pi + 34.35))

# Load map of santabarbara and draw arrows and ridge on it
load("ridgetorus/application/map_santa_barbara.RData")

ridge_index <- function(i){
  print(ggmap(map.st_barbara) + theme(plot.margin = margin(0.1, 0.1, 0, 0,
                                                           "cm")) +
          geom_image(data = d, aes(x = x, y = y, image = image), size = .5) +
          geom_segment(aes(x = -120.904, y = 34.15, xend = -120.025,
                           yend = 34.15), col = "black") +
          scale_y_continuous(limits = c(33.7, 34.5)) + xlab("Longitude") +
          ylab("Latitude") +
          geom_segment(aes(x = -119.5, y = 34.15, xend = -119.5 +
                             arr_1$u[i] / 10, yend = 34.15 + arr_1$v[i] / 10),
                       arrow = arrow(length = unit(0.5, "cm")), col = "red",
                       size = 2, alpha = trans[i]) +
           geom_point(aes(x = -119.5, y = 34.15), alpha = trans[i], size = 2,
                      col = "red")+
           geom_point(aes(x = -119.98, y = 34.055), col = "red", size = 2,
                      alpha = trans[i])+
          geom_segment(aes(x = -119.98, y = 34.055, xend = -119.98 +
                             arr_2$u[i] / 10, yend = 34.055 + arr_2$v[i] / 10),
                       arrow = arrow(length = unit(0.5, "cm")), col = "red",
                       size = 2, alpha = trans[i]) +
          geom_point(aes(x = V1, y = V2), data = theta_miniplot[i,],
                     col = "red", size = 4))

}


# Set of 6 images
n <- length(th1_arc)
for (i in seq(3, n - 2, l = 6)) {

  png(paste(file = "indexing", i, ".PNG",sep = ""), width = 480, height = 342)
  ridge_index(i)
  dev.off()

}

# Video
ani.options('interval' = 0.1, ani.res = "120")
saveVideo(for (i in rep(seq(1, length(th1_arc)),3)) ridge_index(i),
          video.name = "ridge_index_miniplot.avi")

# Checks
fit_s <- ridge_pca(x = santabarbara[c("D", "B")], type = "bwc", scale = TRUE)
fit_u <- ridge_pca(x = santabarbara[c("D", "B")], type = "bwc", scale = FALSE)
set.seed(1); show_ridge_pca(fit = fit_s, col_data = "black")
set.seed(1); show_ridge_pca(fit = fit_u, col_data = "black")
torus_pairs(fit_s$scores, col_data = "black", scales = fit_s$scales)
torus_pairs(fit_u$scores, col_data = "black", scales = fit_u$scales)

# Scores for zone BC and CA
fitbvm <- ridge_pca(x = santabarbara[c("C", "B")], type = "bvm", N = 1e3)
pdf(file = "scoresbvm.pdf")
show_ridge_pca(fit = fitbvm, col_data = "black", n_max = 1e3)
dev.off()

fitbwc <- ridge_pca(x = santabarbara[c("C", "A")], type = "bwc", N = 1e3)
pdf(file = "scoresbwc.pdf")
show_ridge_pca(fit = fitbwc, col_data = "black", n_max = 1e3)
dev.off()

# Plot pairs plots of original data and scores with torus_pairs()
pdf(file = "original_data_CB.pdf")
torus_pairs(santabarbara[c("C", "B")], col_data = "black")
dev.off()
pdf(file = "score_dist_bvm.pdf")
torus_pairs(fitbvm$scores, col_data = "black", scales = fitbvm$scales)
dev.off()

pdf(file = "original_data_CA.pdf")
torus_pairs(santabarbara[c("C", "A")], col_data = "black")
dev.off()
pdf(file = "score_dist_bwc.pdf")
torus_pairs(fitbwc$scores, col_data = "black", scales = fitbwc$scales)
dev.off()

