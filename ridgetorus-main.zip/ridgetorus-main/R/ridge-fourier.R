
#' @title Fourier sine expansion of a given curve
#'
#' @description Computation of the Fourier sine expansion coefficients of a
#' given curve.
#' @param curve points of the curve.
#' @param norm_prop percentage of explained norm.
#' @param N number of Gaussian quadrature points, passed to
#' \link[=sphunif]{Gauss_Legen_nodes}. Defaults to \code{1280}.
#' @return The coefficients of the fit.
#' @author Arturo Prieto-Tirado.
#' @examples
#' ridge <- ridge_bwc(xi1 = 0.1, xi2 = 0.5, rho = 0.5, subintervals_1 = 1e3,
#'                    subintervals_2 = 1e3)
#' plot(ridge)
#' coefs1 <- ridge_fourier_fit(ridge)
#' th <- seq(-pi, pi, l = 500)
#' points(ridge_curve(th, b = coefs1), col = 2)
#' # coefs2 <- ridge_fourier_fit2(ridge)
#' # # Fourier fits
#' # a_k_cos <- coefs2$a_k_cos
#' # b_k_cos <- coefs2$b_k_cos
#' # a_k_sin <- coefs2$a_k_sin
#' # b_k_sin <- coefs2$b_k_sin
#' # K <- length(b_k_cos)
#' # fou_cos <- a_k_cos[1] / 2 +
#' #   colSums(cos((1:K) %o% th) * a_k_cos[-1] + sin((1:K) %o% th) * b_k_cos)
#' # fou_sin <- a_k_sin[1] / 2 +
#' #   colSums(a_k_sin[-1] * cos((1:K) %o% th) + b_k_sin * sin((1:K) %o% th))
#' # fou_atan2 <- atan2(fou_sin, fou_cos)
#' # points(th, fou_atan2, col = 3)
#'
#' ridge <- ridge_bwc(xi1 = 0.2, xi2 = 0.1, rho = 0.8, subintervals_1 = 1e3,
#'                    subintervals_2 = 1e3)
#' plot(ridge)
#' coefs1 <- ridge_fourier_fit(ridge)
#' points(ridge_curve(ridge, b = coefs1), col = 2)
#' # coefs2 <- ridge_fourier_fit2(ridge)
#' # Fourier fits
#' # a_k_cos <- coefs2$a_k_cos
#' # b_k_cos <- coefs2$b_k_cos
#' # a_k_sin <- coefs2$a_k_sin
#' # b_k_sin <- coefs2$b_k_sin
#' # K <- length(b_k_cos)
#' # fou_cos <- a_k_cos[1] / 2 +
#' #   colSums(cos((1:K) %o% th) * a_k_cos[-1] + sin((1:K) %o% th) * b_k_cos)
#' # fou_sin <- a_k_sin[1] / 2 +
#' #   colSums(a_k_sin[-1] * cos((1:K) %o% th) + b_k_sin * sin((1:K) %o% th))
#' # fou_atan2 <- atan2(fou_sin, fou_cos)
#' # points(th, fou_atan2, col = 3)
#' @export
ridge_fourier_fit <- function(curve, norm_prop = 0.999, N = 1280) {

  # Calculate nodes and weights
  nodes <- sphunif::Gauss_Legen_nodes(a = -pi, b = pi, N = N)
  w <- sphunif::Gauss_Legen_weights(a = -pi, b = pi, N = N)

  # Find the closest point of the curve to each node and save its y value
  y <- rep(0, length = N)
  for (i in 1:N) {

    y[i] <- curve[which.min(abs(curve[, 1] - nodes[i])), 2]

  }

  # Squared norm of the curve
  norm_sq <- sum((y^2 * w)) / pi

  # Estimate coefficients until percentage of explained norm is reached
  coefs_sq <- 0
  i <- 1
  coef <- numeric()
  while (coefs_sq / norm_sq < norm_prop) {

    coef <- append(coef, sum((sin(i * nodes) * y * w) / pi))
    coefs_sq <- coefs_sq + coef[i] ^ 2
    i <- i + 1

  }
  return(coef)

}


#' @rdname ridge_fourier_fit
#' @export
ridge_fourier_fit2 <- function(curve, K = 100) {

  # Calculate nodes and weights
  N <- 1280
  nodes <- sphunif::Gauss_Legen_nodes(a = -pi, b = pi, N = N)
  w <- sphunif::Gauss_Legen_weights(a = -pi, b = pi, N = N)

  # Find the closest point of the curve to each node and save its y value
  y <- rep(0, length = N)
  for (i in 1:N) {

    y[i] <- curve[which.min(abs(curve[, 1] - nodes[i])), 2]

  }

  # Sin-cos coefficients
  y_cos <- drop(cos(y))
  y_sin <- drop(sin(y))
  a_k_cos <- sapply(0:K, function(k) sum(cos(k * nodes) * y_cos * w)) / pi
  b_k_cos <- sapply(1:K, function(k) sum(sin(k * nodes) * y_cos * w)) / pi
  a_k_sin <- sapply(0:K, function(k) sum(cos(k * nodes) * y_sin * w)) / pi
  b_k_sin <- sapply(1:K, function(k) sum(sin(k * nodes) * y_sin * w)) / pi

  # Fourier fits
  theta <- curve[, 1]
  fou_cos <- a_k_cos[1] / 2 +
    colSums(cos((1:K) %o% theta) * a_k_cos[-1] + sin((1:K) %o% theta) * b_k_cos)
  fou_sin <- a_k_sin[1] / 2 +
    colSums(a_k_sin[-1] * cos((1:K) %o% theta) + b_k_sin * sin((1:K) %o% theta))
  fou_atan2 <- atan2(fou_sin, fou_cos)

  # Return coefs
  return(list("a_k_cos" = a_k_cos, "b_k_cos" = b_k_cos,
              "a_k_sin" = a_k_sin, "b_k_sin" = b_k_sin))

}


#' atan2_der <- function(y, x) {
#' 
#'   return(cbind(-y, x) / (x^2 + y^2))
#' 
#' }
