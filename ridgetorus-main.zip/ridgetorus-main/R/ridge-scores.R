
#' @title Scores for Fourier-fitted ridge curves
#'
#' @description Computation of PCA scores for \link[=ridge_curve]{
#' Fourier-fitted ridge curves}. The scores are defined as follows:
#' \itemize{
#'   \item First scores: signed distances along the ridge curve of the data
#'   projections to \eqn{mu}.
#'   \item Second scores: signed toroidal distances from the data points to
#'   their ridge projections.
#' }
#'
#' @inheritParams ridge_curve
#' @param scale TODO
#' @return A matrix of size \code{c(nx, 2)} with the ridge scores.
#' @details
#' The mean \eqn{\mu} corresponds to the first score being null.
#' @author Eduardo García-Portugués.
#' @examples
#' mu <- c(-0.5, 1.65)
#' th <- seq(-pi, pi, l = 200)
#' b <- 1 / (1:5)^2
#' n <- 10
#' col <- rainbow(n)
#' set.seed(13213)
#' old_par <- par()
#' par(mfrow = c(2, 2))
#' for (j in 1:2) {
#'
#'   # Simulate synthetic data close to the ridge curve
#'   rid <- ridge_curve(theta = th, mu = mu, b = b, ind_var = j)
#'   ind <- sort(sample(length(th), size = n))
#'   eps <- 0.25 * matrix(runif(2 * n, -1, 1), nrow = n, ncol = 2)
#'   x <- sdetorus::toPiInt(rid[ind, ] + eps)
#'
#'   # Plot ridge and synthetic data, with signs from the second scores
#'   s <- ridge_scores(x, mu = mu, b = b, ind_var = j)$scores
#'   plot(x, xlim = c(-pi, pi), ylim = c(-pi, pi), axes = FALSE,
#'        xlab = expression(theta[1]), ylab = expression(theta[2]), col = col,
#'        pch = ifelse(sign(s[, 2]) == 1, "+", "-"), cex = 1.25)
#'   lines(rid, lwd = 2)
#'   abline(v = mu[1], lty = 3)
#'   abline(h = mu[2], lty = 3)
#'   points(mu[1], mu[2], pch = "*", cex = 3)
#'   sdetorus::torusAxis()
#'
#'   # Projections
#'   theta_projs <- proj_ridge_curve(x = x, mu = mu, b = b, ind_var = j,
#'                                   ridge_curve_grid = rid)$theta_proj
#'   projs <- ridge_curve(theta = theta_projs, mu = mu, b = b, ind_var = j)
#'   for (i in 1:n) {
#'
#'     sdetorus::linesTorus(x = c(x[i, 1], projs[i, 1]),
#'                          y = c(x[i, 2], projs[i, 2]),
#'                          col = col[i], lty = 3)
#'
#'   }
#'
#'   # Scores plot
#'   plot(s, pch = 16, xlim = c(-pi, pi), ylim = c(-pi, pi), axes = FALSE,
#'        xlab = "Score 1", ylab = "Score 2", col = col)
#'   sdetorus::torusAxis()
#'   abline(v = 0, lty = 3)
#'   abline(h = 0, lty = 3)
#'   points(0, 0, pch = "*", cex = 3)
#'
#' }
#' par(old_par)
#' @export
ridge_scores <- function(x, mu = c(0, 0), b = 0, ind_var = 1, N = 1e3,
                         scale = TRUE) {

  ## First scores: distances, along the ridge curve, of the data projections
  ## to mu

  # Construct arc-length parametrization and ridge_curve_grid
  alpha <- arclength_ridge_curve(mu = mu, b = b, ind_var = ind_var,
                                 L = 10 * N, N = N)
  ridge_curve_grid <- ridge_curve(theta = alpha, mu = mu, b = b,
                                  ind_var = ind_var)

  # Projections, including mu for later recentering (so score_1 = 0 if and
  # only if x = mu)
  projs_curve <- proj_ridge_curve(x = rbind(mu, x), mu = mu, b = b,
                                  ind_var = ind_var, N = N,
                                  ridge_curve_grid = ridge_curve_grid)
  scores_1 <- alpha[projs_curve$ind_grid]
  scores_1_mu <- scores_1[1]
  scores_1 <- scores_1[-1]

  ## Second scores: *signed* distances to ridge curve

  # Unsigned distances
  y <- ridge_curve(theta = scores_1, mu = mu, b = b, ind_var = ind_var)
  scores_2 <- torus_dist(x = x, y = y)

  # Assign signs using the sign of the angle between the tangent and normal
  # vectors at the projections
  norms <- sdetorus::toPiInt(y - x)
  tangents <- der_ridge_curve(theta = scores_1, mu = mu, b = b,
                              ind_var = ind_var)
  signs_scores_2 <- sign(sdetorus::toPiInt(
    atan2(tangents[, 2], tangents[, 1]) - atan2(norms[, 2], norms[, 1])
    ))
  scores_2 <- signs_scores_2 * scores_2

  # Centering of scores_1
  scores_1 <- sdetorus::toPiInt(scores_1 - scores_1_mu)

  ## Scale the scores?

  if (scale) {

    # Scale distances to have lie in (-pi, pi) (analogously as it is done with
    # the scores_1 via the arc-length parametrization of the ridge curve)
    scores_2 <- scores_2 / sqrt(2)
    scales <- c(pi, pi)

  } else {

    length_ridge <- dist_ridge_curve(alpha = c(0, 2 * pi), mu = mu, b = b,
                                     ind_var = ind_var, N = 1e4,
                                     shortest = FALSE)
    scores_1 <- scores_1 * length_ridge / (2 * pi)
    scales <- c(length_ridge / 2, sqrt(2) * pi)

  }

  # Return scores and scales
  return(list("scores" = cbind(scores_1, scores_2), "scales" = scales))

}


#' @title Toroidal distances
#'
#' @description Computation of distances in \eqn{[-\pi, \pi)^d}, \eqn{d\geq 2},
#' between two sets of observations.
#'
#' @param x a matrix of size \code{c(nx, d)} with angles in \eqn{[-\pi, \pi)}.
#' @param y either a matrix with the same size as \code{x} or a vector of
#' size \code{nx}.
#' @param squared return the squared distance? Defaults to \code{FALSE}.
#'
#' @return A vector of size \code{nx} with the distances between the
#' observations of \code{x} and \code{y}.
#' @details
#' The maximal distance in \eqn{[-\pi, \pi)^d} is \eqn{\sqrt{d}\pi}.
#' @examples
#' n <- 10
#' x <- matrix(runif(2 * n, -pi, pi), nrow = n, ncol = 2)
#' y <- c(pi / 2, pi / 3)
#' col <- rainbow(n)
#' plot(x, xlim = c(-pi, pi), ylim = c(-pi, pi), axes = FALSE, col = col,
#'      xlab = expression(theta[1]), ylab = expression(theta[2]), pch = 16)
#' sdetorus::torusAxis()
#' points(y[1], y[2], col = 1, pch = 17)
#' for (i in 1:n) {
#'
#'   sdetorus::linesTorus(x = c(x[i, 1], y[1]),
#'                        y = c(x[i, 2], y[2]), lty = 2, col = col[i])
#'
#' }
#' text(x = x, labels = sprintf("%.2f", torus_dist(x, y)), col = col, pos = 1)
#' @export
torus_dist <- function(x, y, squared = FALSE) {

  d2 <- switch(is.vector(y) + 1,
               rowSums(sdetorus::toPiInt(x - y)^2),
               colSums(sdetorus::toPiInt(t(x) - y)^2))
  return(switch(squared + 1, sqrt(d2), d2))

}
