
#' @title Density of the bivariate wrapped Cauchy distribution
#'
#' @description Computation of the density of a bivariate wrapped Cauchy:
#' \eqn{f(\theta_{1}, \theta_{2})=c\{c_{0}-c_{1} \cos (\theta_{1}-\mu_{1})-c_{2}
#' \cos (\theta_{2}-\mu_{2})-c_{3} \cos (\theta_{1}-\mu_{1})
#' \cos (\theta_{2}-\mu_{2})-c_{4} \sin (\theta_{1}-\mu_{1})
#' \sin (\theta_{2}-\mu_{2})\}^{-1} }.
#' @param theta the points where to evaluate the density.
#' @param mu1,mu2 modes of the density on \eqn{\theta_1} and \eqn{\theta_2}.
#' @param xi1,xi2 concentrations of the density on \eqn{\theta_1} and
#' \eqn{\theta_2}.
#' @param rho dependence parameter between \eqn{\theta_1} and \eqn{\theta_2}.
#' @return The value of the density at the point with the given parameters.
#' @author Arturo Prieto-Tirado.
#' @references
#' Kato, S. and Pewsey, A. (2015). A M?bius transformation-induced distribution
#' on the torus. \emph{Biometrika}, 102(2):359--370. \doi{10.1093/biomet/asv003}
#' @examples
#' xi1 <- 0.3
#' xi2 <- 0.5
#' rho <- 0.4
#' nth <- 50
#' th <- seq(-pi, pi, l = nth)
#' x <- as.matrix(expand.grid(th, th))
#' d <- d_bwc(theta = x, xi1 = xi1, xi2 = xi2, rho = rho)
#' filled.contour(th, th, matrix(d, nth, nth), col = viridisLite::viridis(20),
#'                levels = seq(0, max(d), l = 20))
#' @export
d_bwc <- function(theta, mu1 =0, mu2 =0, xi1, xi2, rho) {

  theta <- rbind(theta)
  rho2 <- rho^2
  xi12 <- xi1^2
  xi22 <- xi2^2

  C <- (1 - rho2) * (1 - xi12) * (1 - xi22) / (4 * pi^2)
  c0  <-  (1 + rho2)  *  (1 + xi12)  *  (1 + xi22)  -
    8  *  abs(rho) * xi1 * xi2
  c1 <- 2 * (1 + rho2) * xi1 * (1 + xi22) - 4 * abs(rho) * (1 + xi12) * xi2
  c2 <- 2 * (1 + rho2) * (1 + xi12) * xi2 - 4 * abs(rho) * xi1 * (1 + xi22)
  c3 <- -4 * (1 + rho2) * xi1 * xi2 + 2 * abs(rho) * (1 + xi12) * (1 + xi22)
  c4 <- 2 * rho * (1 - xi12) * (1 - xi22)
  cos1 <- cos(theta[, 1] - mu1)
  cos2 <- cos(theta[, 2] - mu2)
  return(C * (c0 - c1 * cos1 - c2 * cos2 - c3 * cos1 * cos2 -
              c4 * sin(theta[, 1] - mu1) * sin(theta[, 2] - mu2))^ (-1))

}


#' @title Simulation from a bivariate wrapped Cauchy distribution
#'
#' @description Simulation of pairs of circular variables represented by a
#' bivariate wrapped Cauchy.
#' @param n length of the sample.
#' @param mu1,mu2 modes of the density on \eqn{\theta_1} and \eqn{\theta_2}.
#' @param xi1,xi2 concentrations of the density on \eqn{\theta_1} and
#'  \eqn{\theta_2}.
#' @param rho dependence parameter between \eqn{\theta_1} and \eqn{\theta_2}.
#' @return Pairs of circular variables.
#' @author The original code for \code{r_bwc} has been supplied by
#' Arthur Pewsey.
#' @references
#' Kato, S. and Pewsey, A. (2015). A M?bius transformation-induced distribution
#' on the torus. \emph{Biometrika}, 102(2):359--370. \doi{10.1093/biomet/asv003}
#' @examples
#' xi1 <- 0.3
#' xi2 <- 0.5
#' rho <- 0.4
#' n <- 2000
#' sample <- r_bwc(n = n, xi1 = xi1, xi2 = xi2, rho = rho)
#' @export
r_bwc <- function(n, mu1 = 0, mu2=0, xi1 = 0.0, xi2 = 0.0, rho = 0) {

  ## Use Theorem 1 to simulate a random bivariate complex vector (Z1, Z2)

  # Simulate Z1 with marginal density and equation 8
  phi <- abs(rho)
  U1 <- runif(n, 0, 1)
  C1 <- exp(1i * 2 * pi * U1)
  Z1 <- (C1 + xi1) / (xi1 * C1 + 1)

  # Obtain the first circular variable as its argument
  theta1 <- sdetorus::toPiInt(Arg(Z1) + mu1)

  # Simulate Z2 using the conditional marginal and equation 8
  C1inv <- 1 / C1
  tmp <- matrix(runif(2 * n, 0, 1), ncol = 2, byrow = TRUE)
  U2 <- tmp[, 1]
  C2 <- exp(1i * 2 * pi * U2)
  if (rho < 0) {
    alpha2 <- (phi * xi2 * C1 + 1) / (phi * xi2 * C1inv + 1)
    beta2 <- (xi2 + phi * C1inv) / (phi * xi2 * C1 + 1)
  } else if (rho >= 0) {
    alpha2 <- (phi * xi2 * C1inv + 1) / (phi * xi2 * C1 + 1)
    beta2 <- (xi2 + phi * C1) / (phi * xi2 * C1inv + 1)
  }
  Z2 <- alpha2 * (C2 + beta2) / (Conj(beta2) * C2 + 1)

  # Obtain the second circular variable as its argument
  theta2 <- sdetorus::toPiInt(Arg(Z2) + mu2)

  # Return the pair of circular variables
  return(cbind(theta1, theta2))

}


#' @title Estimation of the parameters of a Bivariate Wrapped Cauchy via
#' method of moments and maximum likelihood
#'
#' @description Estimation of the parameters of a bivariate wrapped Cauchy:
#' \eqn{\mu_1, \mu_2, \xi_1, \xi_2, \rho}.
#' @param theta sample of the pair of circular variables.
#' @param initial_values initial values for maximum likelihood optimizer.
#' If \code{NULL} (default), method of moments estimates are employed.
#' @param lower,upper vectors with the bounds for the maximum likelihood
#' optimizer.
#' @return A vector with the parameters \eqn{\mu_1, \mu_2, \xi_1, \xi_2, \rho}.
#' TODO: \code{opt}
#' @author Arturo Prieto-Tirado.
#' @references
#' Kato, S. and Pewsey, A. (2015). A Möbius transformation-induced distribution
#' on the torus. \emph{Biometrika}, 102(2):359--370. \doi{10.1093/biomet/asv003}
#' @examples
#' mu1 <- 0
#' mu2 <- 0
#' xi1 <- 0.3
#' xi2 <- 0.6
#' rho <- 0.25
#' n <- 2000
#' sample <- r_bwc(n, mu1, mu2, xi1, xi2, rho)
#' param_mm <- fit_bwc_mm(sample)
#' param_mle <- fit_bwc_mle(sample)
#' @name fit_bwc


#' @rdname fit_bwc
#' @export
fit_bwc_mm <- function(theta) {

  theta1 <- theta[, 1]
  theta2 <- theta[, 2]
  n <- length(theta1)

  # Circular means
  R1cos <- sum(cos(theta1))
  R1sin <- sum(sin(theta1))
  R2cos <- sum(cos(theta2))
  R2sin <- sum(sin(theta2))
  mu1_hat <- atan2(x = R1cos, y = R1sin)
  mu2_hat <- atan2(x = R2cos, y = R2sin)

  # Concentration parameters
  xi1_hat <- sqrt(R1cos^2 + R1sin^2) / n
  xi2_hat <- sqrt(R2cos^2 + R2sin^2) / n

  # Dependence parameter
  phi1 <- 2 * atan((1 + xi1_hat) / (1 + xi1_hat) * tan((theta1 - mu1_hat) / 2))
  phi2 <- 2 * atan((1 + xi2_hat) / (1 + xi2_hat) * tan((theta2 - mu2_hat) / 2))
  rho_hat <- (sqrt(sum(cos(phi1 - phi2))^2 + sum(sin(phi1 - phi2))^2) -
            sqrt(sum(cos(phi1 + phi2))^2 + sum(sin(phi1 + phi2))^2)) / n

  # Return the set of parameters
  solution <- list(mu1 = mu1_hat, mu2 = mu2_hat, xi1 = xi1_hat, xi2 = xi2_hat,
                   rho = rho_hat)
  return(solution)

}


#' @rdname fit_bwc
#' @export
fit_bwc_mle <- function(theta, initial_values = NULL,
                        lower = c(-pi, -pi, 0 + 1e-3, 0 + 1e-3, -1 + 1e-3),
                        upper = c(pi, pi, 1 - 1e-3, 1 - 1e-3, 1 - 1e-3)) {

  # Function that estimates the minus logarithm of the likelihood of the bwc
  minus_loglik_bwc <- function(param) {

    return(-sum(log(d_bwc(theta = theta, mu1 = param[1], mu2 = param[2],
                          xi1 = param[3], xi2 = param[4], rho = param[5]))))

  }

  # If not provided, obtain starting values by moment estimators
  theta <- rbind(theta)
  if (is.null(initial_values)) {

    initial_values <- unlist(fit_bwc_mm(theta))

  }

  # Optimize the minus log-likelihood
  opt <- sdetorus::mleOptimWrapper(minusLogLik = minus_loglik_bwc,
                                   optMethod = "L-BFGS-B",
                                   start = initial_values,
                                   selectSolution = "lowest",
                                   lower = lower, upper = upper,
                                   checkCircular = TRUE)
  # final_param <- optim(fn = minus_loglik_bvm, method = "L-BFGS-B",
  #                      par = initial_values, theta = theta, lower = lower,
  #              upper = upper)$par
  return(list(mu1 = opt$par[1], mu2 = opt$par[2], xi1 = opt$par[3],
              xi2 = opt$par[4], rho = opt$par[5], opt = opt))

}
