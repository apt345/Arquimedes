
#' @title Toroidal PCA via density ridges
#'
#' @description This function computes the whole process of toroidal PCA
#' estimation via density ridges on a given sample: parameter estimation of the
#' underlying distribution, estimation of the connected component of the ridge
#' and its Fourier expansion from which to obtain the first and second scores.
#'
#' @param x bivariate sample of toroidal data.
#' @param type one of the two types of distributions: bivariate von Mises "bvm"
#' or bivariate wrapped Cauchy "bwc".
#' @inheritParams ridge_curve
#' @inheritParams ridge_scores
#' @return List with:
#' \itemize{
#'   \item Estimated circular means of the sample.
#'   \item Estimated Fourier sine coefficients.
#'   \item Independent variable: either 1 for x-axis and 2 for y-axis.
#'   \item Value of the first and second score for each of the sample points.
#'   \item Percentage of explained variance.
#'   \item Parameters of the distribution fit.
#'   \item BIC of the fit.
#'   \item Original sample.
#'   \item Scales TODO
#' }
#' @author Eduardo García-Portugués and Arturo Prieto-Tirado.
#' @examples
#' n <- 1000
#' x <- r_bvm(mu1 = 0, mu2 = 0, k1 = 0.3, k2 = 0.6, lambda = 0.4, n = n)
#' # ridge_pca and its visualization
#' fit <- ridge_pca(x = x)
#' show_ridge_pca(fit = fit, col_data = "red")
#' @export
ridge_pca <- function(x, type = c("bvm", "bwc")[1], N = 1e3, scale = TRUE) {

  # Sample size
  n <- nrow(x)

  # Estimation of underlying distribution
  if (type == "bvm") {

    # Estimation of bvm parameters
    mod_fit <- fit_bvm_mle(theta = x)
    BIC_fit <- 5 * log(n) + 2 * mod_fit$opt$value

  } else if (type == "bwc") {

    # Estimation of bwc parameters
    mod_fit <- fit_bwc_mle(theta = x) 
    BIC_fit <- 5 * log(n) + 2 * mod_fit$opt$value

  } else {

    stop("type must be \"bvm\" or \"bwc\".")

  }
  mu_hat <- c(mod_fit$mu1, mod_fit$mu2)

  # Ridge computation
  if (type == "bvm") {

    # Connected component of the ridge for bvm
    ridge <- ridge_bvm(mu1 = mod_fit$mu1, mu2 = mod_fit$mu2, k1 = mod_fit$k1,
                       k2 = mod_fit$k2, lambda = mod_fit$lambda,
                       subintervals_1 = 1000, subintervals_2 = 1000)

  } else if (type == "bwc") {

    # Connected component of the ridge for bwc
    ridge <- ridge_bwc(mu1 = mod_fit$mu1, mu2 = mod_fit$mu2, xi1 = mod_fit$xi1,
                       xi2 = mod_fit$xi2, rho = mod_fit$rho,
                       subintervals_1 = 1000, subintervals_2 = 1000)

  }

  # Fourier fit indexed by lowest kappa or xi variable
  ind_var <- order(unlist(mod_fit[3:4]))[1]
  if (ind_var == 2) {

    ridge <- sdetorus::toPiInt(t(t(ridge[, 2:1]) - mu_hat[2:1]))

  } else {

    ridge <- sdetorus::toPiInt(t(t(ridge) - mu_hat))

  }

  # Estimate coefficients
  b_hat <- ridge_fourier_fit(ridge)

  # Scores computation
  scores <- ridge_scores(x = x, mu = mu_hat, b = b_hat, ind_var = ind_var,
                         N = N, scale = scale)

  # Proportion of explained variances
  var_exp <- frechet_ss(x = scores$scores, l = scores$scales)$var_exp

  # Ridge fit
  return(list("mu_hat" = mu_hat, "b_hat" = b_hat, "inv_var" = ind_var,
              "scores" = scores$scores, "var_exp" = var_exp,
              "mod_fit" = mod_fit, "BIC_fit" = BIC_fit, "data" = x,
              "scales" = scores$scales))

}
