
#' @title Density of the bivariate sine von Mises distribution
#'
#' @description Computation of the density and normalizing constant of the
#' bivariate sine von Mises.
#'
#' @param x matrix of size \code{c(n, 2)} with the angles on which the density
#' is evaluated.
#' @param mu vector of length \code{2} with the means \eqn{\mu_1} and
#' \eqn{\mu_2} in each component.
#' @param kappa vector of length \code{3} with the concentrations \eqn{\kappa_1}
#' and \eqn{\kappa_2} (first two entries) and the dependence parameter
#' \eqn{\lambda} (third entry).
#' @param log_const logarithm of the normalizing constant. Computed internally
#' if \code{NULL} (default).
#' @param M truncation of the series expansion for computing the normalizing
#' constant.
#' @return A vector of length \code{n} with the density evaluated at \code{x}.
#' @references
#' Singh, H., Hnizdo, V. and Demchuk, E. (2002). Probabilistic model for two
#' dependent circular variables. \emph{Biometrika}, 89(3), 719--723.
#' \doi{10.1093/biomet/89.3.719}
#' @examples
#' kappa <- 3:1
#' mu <- rep(0, 2)
#' nth <- 50
#' th <- seq(-pi, pi, l = nth)
#' x <- as.matrix(expand.grid(th, th))
#' const <- const_bvm(kappa = kappa)
#' d <- d_bvm(x = x, mu = mu, kappa = kappa, log_const = log(const))
#' d0 <- d_bvm(x = x, mu = mu, kappa = kappa, log_const = 0)
#' filled.contour(th, th, matrix(d, nth, nth), col = viridisLite::viridis(31),
#'                levels = seq(0, max(d), l = 30), main = "Normalized")
#' filled.contour(th, th, matrix(d0, nth, nth), col = viridisLite::viridis(31),
#'                levels = seq(0, max(d0), l = 30), main = "Unnormalized")
#' @author Eduardo Garc?a-Portugu?s (\email{edgarcia@@est-econ.uc3m.es}).
#' @export
d_bvm <- function(x, mu, kappa, log_const = NULL) {

  x <- rbind(x)
  # Normalizing constant
  if (missing(log_const)) {

    log_const <- log(const_bvm(kappa = kappa))

  }

  # Differences
  th_mu_1 <- x[, 1] - mu[1]
  th_mu_2 <- x[, 2] - mu[2]

  # Density
  exp(-log_const + kappa[1] * cos(th_mu_1) + kappa[2] * cos(th_mu_2) +
        kappa[3] * sin(th_mu_1) * sin(th_mu_2) / 2)

}


#' @rdname d_bvm
#' @export
const_bvm <- function(M = 25, kappa) {

  m <- 0:M
  if (all(kappa > 0)) {
    const <- 4 * pi^2 * sum(exp(lchoose(n = 2 * m, k = m) +
    m * (2 * (log(kappa[3]) - log(4)) - log(kappa[1]) - log(kappa[2])) +
    kappa[1] + log(besselI(x = kappa[1], nu = m, expon.scaled = TRUE)) +
    kappa[2] + log(besselI(x = kappa[2],  nu = m, expon.scaled = TRUE))))
  }
  else if (kappa[3] < 1e-15) {
    const <- 4 * pi^2 * besselI(x = kappa[1], nu = 0) *
      besselI(x = kappa[2], nu = 0)
  } else {
    warning(paste("No series expansion for kappa1 == 0 or kappa2 == 0 and",
                  "lambda != 0. This is a bimodal density!",
                  "Using Monte Carlo integration"))
    const <- 1 / sdetorus::mcTorusIntegrate(f = function(x) d_bvm(x = x,
                            mu = c(0, 0), kappa = kappa, log_const = 0), p = 2,
                                M = 1e5, fVect = TRUE)
  }
  return(const)

}


#' @title Simulation from a bivariate von Mises (sine) distribution
#' @description Function that simulates from a bivariate von Mises (sine).
#' @param n length of the sample.
#' @param mu1,mu2 modes of the density on \eqn{\theta_1} and \eqn{\theta_2}.
#' @param k1,k2 concentrations of the density on \eqn{\theta_1} and
#' \eqn{\theta_2}.
#' @param lambda dependence parameter between \eqn{\theta_1} and \eqn{\theta_2}.
#' @return A vector with two components corresponding to the values of each of
#' the circular random variables.
#' @examples
#' mu1 <- 0
#' mu2 <- 0
#' k1 <- 0.3
#' k2 <- 0.6
#' lambda <- 0.25
#' n <- 50
#' sample <- r_bvm(n, mu1, mu2, k1, k2, lambda)
#' @export
r_bvm <- function(n, mu1, mu2, k1, k2, lambda) {

  sample <- BAMBI::rvmsin(n = n, kappa1 = k1, kappa2 = k2, kappa3 = lambda,
                          mu1 = mu1, mu2 = mu2)
  return(sdetorus::toPiInt(sample))

}


#' @title Estimation of the parameters of a bivariate (sine) von Mises via
#' method of moments and Maximum Likelihood
#'
#' @description Estimation of the parameters \eqn{\mu_1, \mu_2, \kappa_1,
#' \kappa_2, \lambda}.
#'
#' @param theta matrix of dimension \code{c(n, 2)} containing the \code{n}
#' observations of the pair of angles.
#' @inheritParams fit_bwc
#' @return A vector with the parameters \eqn{\mu_1, \mu_2, \kappa_1,
#'  \kappa_2, \lambda}. TODO: \code{opt}
#' @references
#' Mardia, K. V., Hughes, G., Taylor, C. C., and Singh, H. (2008).
#' A multivariate von Mises with applications to bioinformatics.
#' \emph{Canadian Journal of Statistics}, 36(1):99--109.
#' \doi{10.1002/cjs.5550360110}
#' @examples
#' mu1 <- 0
#' mu2 <- 0
#' k1 <- 0.3
#' k2 <- 0.6
#' lambda <- 0.25
#' n <- 100
#' sample <- r_bvm(n, mu1, mu2, k1, k2, lambda)
#' param_mm <- fit_bvm_mm(sample)
#' param_mle <- fit_bvm_mle(sample)
#' @name fit_bvm


#' @rdname fit_bvm
#' @export
fit_bvm_mm <- function(theta) {

  # Circular means
  R1cos <- sum(cos(theta[, 1]))
  R1sin <- sum(sin(theta[, 1]))
  R2cos <- sum(cos(theta[, 2]))
  R2sin <- sum(sin(theta[, 2]))
  mu_hat1 <- atan2(x = R1cos, y = R1sin)
  mu_hat2 <- atan2(x = R2cos, y = R2sin)

  # Auxiliary variables
  nu1 <- mean(cos(theta[, 1] - mu_hat1))
  nu2 <- mean(cos(theta[, 2] - mu_hat2))
  nu12 <- mean(sin(theta[, 1] - mu_hat1) * sin(theta[, 2] - mu_hat2))

  # Concentration parameters
  k1_hat <- besselI(x = nu1, nu = 0, expon.scaled = TRUE) /
    besselI(x = nu1, nu = 1, expon.scaled = TRUE)
  k2_hat <- besselI(x = nu2, nu = 0, expon.scaled = TRUE) /
    besselI(x = nu2, nu = 1, expon.scaled = TRUE)

  # Equations for iteration
  equation_lambda_hat <- function(lambda_hat, k1_hat, k2_hat) {

    s <- 0
    for (m in (1:20)) {
      s <- s + m * choose(2 * m, m) * (lambda_hat^2 / (k1_hat * k2_hat))^m *
        besselI(x = k1_hat, nu = m) * besselI(x = k2_hat, nu = m) /
        (lambda_hat * const_bvm(kappa = c(k1_hat, k2_hat, 2 * abs(lambda_hat))))
    }
    return(s - nu12)

  }

  equation_k <- function(k1_hat, k2_hat, lambda_hat, nu, M = 10) {

    summatory1 <- 0
    summatory2 <- 0
    for (m in 1:M) {

      common_log_term <- log(m) + lchoose(2 * m, m) +
        m * log(lambda_hat^2 / (4 * k1_hat * k2_hat)) +
        log(besselI(x = k2_hat, nu = m, expon.scaled = TRUE)) + k2_hat
      log_term1 <- log(besselI(x = k1_hat, nu = m + 1, expon.scaled = TRUE)) +
        k1_hat
      log_term2 <- log(besselI(x = k1_hat, nu = m, expon.scaled = TRUE)) +
        k1_hat
      summatory1 <- summatory1 + exp(common_log_term + log_term1)
      summatory2 <- summatory2 + exp(common_log_term + log_term2)

    }
    return(summatory1 / summatory2 - nu)

  }

  # Iterate a few times to find the method of moments solution
  for (i in 1:20) {

    lambda_hat <- optim(par = 0.5, method = "Brent", fn = equation_lambda_hat,
                    lower = -5, upper = 5, k1_hat = k1_hat,
                    k2_hat = k2_hat)$par
    k1_hat <- optim(par = k1_hat, method = "Brent",
                fn = function(k1_hat, k2_hat, lambda_hat) equation_k(k1_hat,
                      k2_hat, lambda_hat, nu1), lower = 0,
                upper = 5, k2_hat = k2_hat, lambda_hat = lambda_hat)$par
    k2_hat <- optim(par = k2_hat, method = "Brent",
               fn = function(k1_hat, k2_hat, lambda_hat) equation_k(k1_hat,
                                                      k2_hat, lambda_hat, nu2),
            lower = 0, upper = 5, k1_hat = k1_hat, lambda_hat = lambda_hat)$par
  }

  # Vector with the parameters
  solution <- list(mu1 = mu_hat1, mu2 = mu_hat2, k1 = k1_hat, k2 = k2_hat,
                   lambda = lambda_hat)
  return(solution)

}


#' @rdname fit_bvm
#' @export
fit_bvm_mle <- function(theta, initial_values = NULL,
                        lower = c(-pi, -pi, 1e-3, 1e-3, -50),
                        upper = c(pi, pi, 50, 50, 50)) {

  # Function that estimates the minus logarithm of the likelihood of the bvm
  minus_loglik_bvm <- function(param) {

    n <- length(theta[, 1])
    thMu1 <- theta[, 1] - param[1]
    thMu2 <- theta[, 2] - param[2]
    kappa <- c(param[3], param[4], 2 * abs(param[5]))
    logLik <- sum(param[3] * cos(thMu1) + param[4] * cos(thMu2) +
                   param[5] * sin(thMu1) * sin(thMu2)) -
      log(const_bvm(kappa = kappa)) * n
    return(-logLik)

  }

  # If not provided, obtain starting values by moment estimators
  theta <- rbind(theta)
  if (is.null(initial_values)) {

    initial_values <- unlist(fit_bvm_mm(theta = theta))

  }

  # Optimize the minus log-likelihood
  opt <- sdetorus::mleOptimWrapper(minusLogLik = minus_loglik_bvm,
                                   optMethod = "L-BFGS-B",
                                   start = initial_values,
                                   selectSolution = "lowest",
                                   lower = lower, upper = upper,
                                   checkCircular = TRUE)
  # final_param <- optim(fn = minus_loglik_bvm, method = "L-BFGS-B",
  #                      par = initial_values, theta = theta, lower = lower,
  #              upper = upper)$par
  return(list(mu1 = opt$par[1], mu2 = opt$par[2], k1 = opt$par[3],
              k2 = opt$par[4], lambda = opt$par[5], opt = opt))

}
