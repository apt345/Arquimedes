
#' @title Second eigenvalue of the Hessian
#'
#' @description Computation of the second eigenvalue of the Hessian for
#' bivariate von Mises and wrapped Cauchy densities.
#' @param theta the points where to evaluate the density.
#' @param k1,k2 concentrations of the density on \eqn{\theta_1} and
#' \eqn{\theta_2}.
#' @param lambda dependence parameter between \eqn{\theta_1} and \eqn{\theta_2}.
#' @inheritParams d_bwc
#' @param type either \code{"bvm"} for the bivariate von Mises sine or
#' \code{"bwc"} for the bivariate wrapped Cauchy
#' @return The value of the second eigenvalue at the point with the given
#' parameters.
#' @author Arturo Prieto-Tirado.
#' @examples
#' xi1 <- 0.3
#' xi2 <- 0.5
#' rho <- 0.4
#' nth <- 50
#' th <- seq(-pi, pi, l = nth)
#' x <- as.matrix(expand.grid(th, th))
#' d <- H_eigenval_2(theta = x, xi1 = xi1, xi2 = xi2, rho = rho, type = "bwc")
#' filled.contour(th, th, matrix(d, nth, nth), col = viridisLite::viridis(20),
#'                levels = seq(min(d), max(d), l = 20))
#' @export
H_eigenval_2 <- function(theta, k1, k2, lambda, xi1, xi2, rho, type) {

  theta <- rbind(theta)

  if (type == "bvm") {

    # Organize different terms
    sin1 <- sin(theta[, 1])
    cos1 <- cos(theta[, 1])
    sin2 <- sin(theta[, 2])
    cos2 <- cos(theta[, 2])
    sin12 <- sin1 * sin2

    # First derivatives
    C1 <- -k1 * sin1 + lambda * cos1 * sin2
    C2 <- -k2 * sin2 + lambda * sin1 * cos2
    C3 <- -k1 * cos1 - lambda * sin12
    C4 <- -k2 * cos2 - lambda * sin12
    C5 <- lambda * cos1 * cos2

    # Density value
    fvalue <- exp(k1 * cos1 + k2 * cos2 + lambda * sin12)

    # Second derivatives
    u <- (C3 + C1^2) * fvalue
    w <- (C4 + C2^2) * fvalue
    v <- (C5 + C1 * C2) * fvalue

    # Second eigenvalue
    rootd <- sqrt((w - u)^2 + 4 * v^2)
    return((u + w - rootd) / 2)

  } else if (type == "bwc") {

    # Define constants
    rho2 <- rho^2
    xi12 <- xi1^2
    xi22 <- xi2^2
    c0 <- (1 + rho2) * (1 + xi12) * (1 + xi22) - 8 * abs(rho) * xi1 * xi2
    c1 <- 2 * (1 + rho2) * xi1 * (1 + xi22) - 4 * abs(rho) * (1 + xi12) * xi2
    c2 <- 2 * (1 + rho2) * (1 + xi12) * xi2 - 4 * abs(rho) * xi1 * (1 + xi22)
    c3 <- -4 * (1 + rho2) * xi1 * xi2 + 2 * abs(rho) * (1 + xi12) * (1 + xi22)
    c4 <- 2 * rho * (1 - xi12) * (1 - xi22)
    sin1 <- sin(-theta[, 1])
    cos1 <- cos(theta[, 1])
    sin2 <- sin(-theta[, 2])
    cos2 <- cos(theta[, 2])
    c1sin1 <- c1 * sin1
    c2sin2 <- c2 * sin2
    sin12 <- sin1 * sin2
    cos12 <- cos1 * cos2
    sin1cos2 <- sin1 * cos2
    sin2cos1 <- sin2 * cos1
    denominatorsq <- (c0 - c1 * cos1 - c2 * cos2 - c3 * cos12 - c4 * sin12)^2

    # Second derivatives
    u <- (c1sin1 + c3 * sin1cos2 - c4 * sin2cos1) *
      (2 * c1sin1 + 2 * c3 * sin1cos2 - 2 * c4 * sin2cos1) /
      (c0 - c1 * cos1 - c2 * cos2 - c3 * cos12 - c4 * sin12)^3 +
      (-c1 * cos1 - c3 * cos12 - c4 * sin12) / denominatorsq
    w <- (c2sin2 + c3 * sin2cos1 - c4 * sin1cos2) *
      (2 * c2sin2 + 2 * c3 * sin2cos1 - 2 * c4 * sin1cos2) /
      (c0 - c1 * cos1 - c2 * cos2 - c3 * cos12 - c4 * sin12)^3 +
      (-c2 * cos2 - c3 * cos12 - c4 * sin12) / denominatorsq
    v <- (c3 * sin12 + c4 * cos12) / denominatorsq +
      (c1sin1 + c3 * sin1cos2 - c4 * sin2cos1) *
      (2 * c2sin2 + 2 * c3 * sin2cos1 - 2 * c4 * sin1cos2) /
      (c0 - c1 * cos1 - c2 * cos2 - c3 * cos12 - c4 * sin12)^3

    # Second eigenvalue
    rootd <- sqrt((w - u)^2 + 4 * v^2)
    return((u + w - rootd) / 2)

  }

}


#' @title Connected component that goes through the mode
#'
#' @description Computation of the connected component that goes through the
#' mode of the density ridge.
#' @param solution the full set of points belonging to the ridge.
#' @param quadrant first or second quadrant.
#' @param max_dist maximum distance to be considered between points.
#' @return The points of the connected component of the ridge that goes through
#' the mode.
#' @author Arturo Prieto-Tirado.
#' @examples
#' xi1 <- 0.3
#' xi2 <- 0.5
#' rho <- 0.4
#' nth <- 50
#' th <- seq(-pi, pi, l = nth)
#' x <- as.matrix(expand.grid(th, th))
#' d <- d_bwc(theta = x, xi1 = xi1, xi2 = xi2, rho = rho)
#' filled.contour(th, th, matrix(d, nth, nth), col = viridisLite::viridis(20),
#'                levels = seq(0, max(d), l = 20))
#' @export
filtering <- function(solution, quadrant, max_dist = 0.1) {

  # Take points in the given quadrant
  if (quadrant == 1) {
    solution <- solution[solution[, 1] >= 0, ]
    solution <- solution[solution[, 2] >= 0, ]
  }else if (quadrant == 2) {
    solution <- solution[solution[, 1] <= 0, ]
    solution <- solution[solution[, 2] >= 0, ]
  }

  theta1 <- solution[, 1]
  theta2 <- solution[, 2]

  # Initialize points in the connected component of the ridge
  theta1def <- c(0)
  theta2def <- c(0)

  lastpoint <- c(0, 0)

  # While the closest point is near enough, keep adding points
  while (min(sqrt((theta1 - lastpoint[1])^2
                  + (theta2 - lastpoint[2])^2)) < max_dist) {

    # Calculate all distances
    distances <- sqrt((theta1 - lastpoint[1])^2 + (theta2 - lastpoint[2])^2)

    # Find the index of the point with the minimum distance
    index <- which.min(distances)

    # Find the closest point and update last_point
    closest_point <- solution[index, ]
    lastpoint <- closest_point

    # Update definitive list of points
    theta1def <- append(theta1def, closest_point[1])
    theta2def <- append(theta2def, closest_point[2])

    # Remove the point from the initial matrix
    theta1 <- theta1[-index]
    theta2 <- theta2[-index]
    solution <- solution[-index, ]

  }

  # Calculate the remaining points by symmetry (excluding 0,0)
  theta1def <- append(theta1def, -theta1def[-1])
  theta2def <- append(theta2def, -theta2def[-1])

  # Return a matrix with the connected component
  filtered_matrix <- matrix(nrow = length(theta1def), ncol = 2)
  filtered_matrix[, 1] <- theta1def
  filtered_matrix[, 2] <- theta2def
  return(filtered_matrix)

}


#' @title Connected component of the density ridge of a bivariate wrapped
#' Cauchy
#'
#' @description Computation of the connected component of the density ridge of
#' a bivariate wrapped Cauchy density in a given set of points or,
#' if not specified, in a regular grid in \eqn{[-\pi, \pi]}.
#'
#' @param mu1,mu2 modes of the density on \eqn{\theta_1} and \eqn{\theta_2}.
#' @param xi1,xi2 concentrations of the density on \eqn{\theta_1} and
#' \eqn{\theta_2}.
#' @param rho dependence parameter between \eqn{\theta_1} and \eqn{\theta_2}.
#' @param eval_points evaluation points for the ridge.
#' @param subintervals_1 number of points for \eqn{\theta_1}.
#' @param subintervals_2 number of points for \eqn{\theta_2} at each
#' \eqn{\theta1}.
#' @return The points of the connected component of the ridge.
#' @author Arturo Prieto-Tirado.
#' @examples
#' xi1 <- 0.3
#' xi2 <- 0.6
#' rho <- 0.25
#' nth <- 100
#' th <- seq(-pi, pi, l = nth)
#' x <- as.matrix(expand.grid(th, th))
#' d <- d_bwc(theta = x, xi1 = xi1, xi2 = xi2, rho = rho)
#' image(th, th, matrix(d, nth, nth), col = viridisLite::viridis(20))
#' ridge <- ridge_bwc(xi1 = xi1, xi2 = xi2, rho = rho, subintervals_1 = 2000,
#' subintervals_2 = 2000)
#' points(ridge)
#' @export
ridge_bwc <- function(mu1 = 0, mu2 = 0, xi1, xi2, rho, eval_points,
                      subintervals_1, subintervals_2) {

  if (missing(eval_points)) {

    theta1 <- seq(-pi, pi, l = subintervals_1)

  } else {

    theta1 <- eval_points

  }

  # Limit cases with explicit solution
  if (xi1/xi2 == 1) {

    sol_matrix <- matrix(nrow = length(theta1), ncol = 2)
    sol_matrix[, 1] <- theta1
    sol_matrix[, 2] <- sign(rho) * theta1
    return(sol_matrix)

  } else {

    # Search through theta1 for the possible solution(s) of theta2
    solution_theta1 <- c()
    solution_theta2 <- c()

    for (i in(1:subintervals_1)) {

      # Solve ridge implicit equation for candidate points
      sol <- rootSolve::uniroot.all(implicit_bwc, theta1 = theta1[i],
                         xi1 = xi1, xi2 = xi2, rho = rho, interval = c(-pi,pi),
                         n = subintervals_2, tol = 1e-8)

      # Check for NAs (no solution at that theta1)
      sol <- na.omit(sol)
      lsol <- length(sol)

      if (lsol >= 1) {

        isridge <- numeric(length = lsol)

        for (j in (1:lsol)) {

          # Check the eigenvalue condition for each candidate
          isridge[j] <- H_eigenval_2(c(theta1[i], sol[j]), xi1 = xi1, xi2 = xi2,
                                     rho = rho, type = "bwc") <= 0

        }

        sol <- sol[isridge == 1]
        sol <- sol[abs(implicit_bwc(theta2 = sol, theta1 = theta1[i],
                                   xi1 = xi1, xi2 = xi2, rho = rho)) < 0.0001]

        # Store the results
        theta1sol <- rep(theta1[i], length(sol))
        solution_theta1 <- append(solution_theta1, theta1sol)
        solution_theta2 <- append(solution_theta2, sol)
      }

    }

    # Matrix with results
    sol_matrix <- matrix(nrow = length(solution_theta1), ncol = 2)
    sol_matrix[,1] <- solution_theta1
    sol_matrix[,2] <- solution_theta2

    # Use filtering function to obtain the connected component that goes
    # through the mode
    quadrant <- 1
    if (sign(rho) == -1) {
      quadrant <- 2
    }
    sol_matrix_filtered <- filtering(sol_matrix, quadrant = quadrant)
    sol_matrix_filtered[, 1] <- sdetorus::toPiInt(sol_matrix_filtered[, 1] +
                                                    mu1)
    sol_matrix_filtered[, 2] <- sdetorus::toPiInt(sol_matrix_filtered[, 2] +
                                                    mu2)

    # Final results
    return(sol_matrix_filtered)

  }

}


#' @title Connected component of the density ridge of a bivariate sine von
#' Mises
#'
#' @description Computation of the connected component of the density ridge of
#' bivariate sine von Mises in a given set of points or, if not specified, in
#' a regular grid in \eqn{[-\pi, \pi]}.
#' @param mu1,mu2 modes of the density on \eqn{\theta_1} and \eqn{\theta_2}.
#' @param k1,k2 concentrations of the density on \eqn{\theta_1} and
#' \eqn{\theta_2}.
#' @param lambda dependence parameter between \eqn{\theta_1} and \eqn{\theta_2}.
#' @param eval_points evaluation points for the ridge.
#' @param subintervals_1 number of points for \eqn{\theta_1}.
#' @param subintervals_2 number of points for \eqn{\theta_2} at each
#' \eqn{\theta1}.
#' @return The points of the connected component of the ridge.
#' @author Arturo Prieto-Tirado.
#' @references
#' Ozertem, U. and Erdogmus, D. (2011). Locally defined principal curves and
#' surfaces. \emph{Journal of Machine Learning Research}, 12(34):1249--1286.
#' \doi{10.6083/M4ZG6Q60}
#' @examples
#' k1 <- 0.3
#' k2 <- 0.5
#' lambda <- 0.4
#' nth <- 100
#' th <- seq(-pi, pi, l = nth)
#' x <- as.matrix(expand.grid(th, th))
#' d <- d_bvm(x = x, mu = c(0,0), kappa = c(k1, k2, 2 * lambda))
#' image(th, th, matrix(d, nth, nth), col = viridisLite::viridis(20))
#' ridge <- ridge_bvm(k1 = k1, k2 = k2, lambda = lambda, subintervals_1 = 2000,
#' subintervals_2 = 1000)
#' points(ridge)
#' @export
ridge_bvm <- function(mu1 = 0, mu2 = 0, k1, k2, lambda, eval_points,
                      subintervals_1, subintervals_2) {
  
  # Limit cases with explicit solution
  if (k1/k2 == 1) {
    if (k1 > lambda) {
      limit <- acos(lambda / k1)
      if (missing(eval_points)) {
        theta1 <- seq(-pi + limit, pi - limit, l = subintervals_1)
      } else {
        theta1 <- eval_points[abs(eval_points) < (-pi + limit)]
      }
      
    } else {
      if (missing(eval_points)) {
        theta1 <- seq(-pi, pi, l = subintervals_1)
      } else {
        theta1 <- eval_points
      }
    }

    sol_matrix <- matrix(nrow = length(theta1), ncol = 2)
    sol_matrix[, 1] <- theta1
    sol_matrix[, 2] <- sign(lambda) * theta1
    return(sol_matrix)

  } else {

    # Search through theta1 for the possible solution(s) of theta2
    if (missing(eval_points)) {
      theta1 <- seq(-pi, pi, l = subintervals_1)
    } else {
      theta1 <- eval_points
    }
    solution_theta1 <- c()
    solution_theta2 <- c()

    for (i in(1:subintervals_1)) {

      # Solve ridge implicit equation for candidate points
      sol <- rootSolve::uniroot.all(implicit_bvm, theta1 = theta1[i],
                         kappa = c(k1, k2, lambda), interval = c(-pi, pi),
                         n = subintervals_2, tol = 1e-8)

      # Check for NAs (no solution at that theta1)
      sol <- na.omit(sol)
      lsol <- length(sol)

      # Check the eigenvalue condition for each candidate
      if (lsol >= 1) {

        isridge <- numeric(length = lsol)

        for (j in (1:lsol)) {
          
          isridge[j] <- H_eigenval_2(c(theta1[i], sol[j]), k1 = k1,
                                    k2 = k2, lambda = lambda, type = "bvm") <= 0

        }

        sol <- sol[isridge == 1]
        sol <- sol[abs(implicit_bvm(theta2 = sol, theta1 = theta1[i],
                                   kappa = c(k1, k2, lambda))) < 0.0001]

        # Store the results
        theta1sol <- rep(theta1[i], length(sol))
        solution_theta1 <- append(solution_theta1, theta1sol)
        solution_theta2 <- append(solution_theta2, sol)
      }

    }

    # Matrix with results
    sol_matrix <- matrix(nrow = length(solution_theta1), ncol = 2)
    sol_matrix[,1] <- solution_theta1
    sol_matrix[,2] <- solution_theta2

    # Use filtering function to obtain the connected component that goes
    # through the mode
    if (lambda < 0) {
      quadrant <- 2
    } else {
      quadrant <- 1
    }
    sol_matrix_filtered <- filtering(sol_matrix, quadrant = quadrant)
    sol_matrix_filtered[, 1] <- sdetorus::toPiInt(sol_matrix_filtered[,1] + mu1)
    sol_matrix_filtered[, 2] <- sdetorus::toPiInt(sol_matrix_filtered[,2] + mu2)

    # Final results
    return(sol_matrix_filtered)

  }

}