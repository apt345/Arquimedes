

#' @title Santa Barbara currents
#'
#' @description Santa Barbara data from the
#' \href{https://hfradar.ndbc.noaa.gov/}{
#' NOAA High Frequency Radar National Server.}
#' measures ocean currents at given time and location, which represent
#' a vector on \eqn{S^1}.
#'
#' @docType data
#' @format A data frame with 1098 rows and 4 variables:
#' \describe{
#'   \item{A}{Data from zone A.}
#'   \item{B}{Data from zone B.}
#'   \item{C}{Data from zone C.}
#'   \item{D}{Data from zone D.}
#' }
#' @details
#' The direction is measured in radians in \eqn{[-\pi, \pi]} with the East
#' associated to 0 and the North associated to \eqn{\pi/2}.
#'
#' The script performing the data preprocessing is available at
#' \href{https://github.com/apt345/ridgetorus/blob/master/data-raw/santabarbara.R}{
#' \code{santabarbara.R}}. The data was retrieved on 2021-07-01.
#' @source \url{http://hfrnet-tds.ucsd.edu/thredds/dodsC/HFR/USWC/2km/hourly/
#' RTV/HFRADAR_US_West_Coast_2km_Resolution_Hourly_RTV_best.ncd}
#' @references
#' García-Portugués and Prieto-Tirado (2021) <arXiv:2109.XXXXX>
#' @examples
#' # Load data
#' data("santabarbara")
#' AB_zone <- santabarbara[c("A","B")]
#' AB_zone <- AB_zone[complete.cases(AB_zone),]
#'
#' # TODO
#' fit <- ridge_pca(x = AB_zone)
#'
#' # Plot results
#' # TODO
"santabarbara"
