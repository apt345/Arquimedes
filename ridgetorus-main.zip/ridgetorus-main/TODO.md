
# R

- [x] Add reliable simulation for BvM.
- [x] Replace EM algorithm in BvM with a function for doing ML estimation (that is, extract the function `minus_weighted_loglik`), then remove `d_bvm_mixt`.
- [x] Add BWC.R: density computation, parameter estimation via ML, and simulation.
- [x] Modify the data generated in the ridge-related examples with data sampled from BVM/BWC.
- [x] Function `ridge_fourier_fit` for doing the Fourier fit.
- [x] Develop the structure for function `ridgepca` -- must be modularized! Option for choosing between BVM and BWC. Stuff that needs to do for the moment:
    1. Estimate model (or not, if parameters are provided).
    2. Obtain ridge.
    3. Fit ridge with Fourier.
- [x] Compute scores and return graphics -- this will be handled by Edu.
- [ ] Add BWN.R: density computation (in C++ -- Edu has code for this), parameter estimation via ML (Edu has initial code for this, see below), and simulation (trivial).

      ``` 
      # MLE
      # DirStats::dwntd -> Needs to be replaced by our own function
      ml1 <- circular::mle.wrappednormal(x = circular::circular(data[, 1]))
      ml2 <- circular::mle.wrappednormal(x = circular::circular(data[, 2]))
      ml <- sdetorus::mleOptimWrapper(minusLogLik = function(x) {
        -sum(log(DirStats::dwntd(th1 = data[, 1], th2 = data[, 2], mu1 = x[1],
                                 mu2 = x[2], sigma1 = x[3], sigma2 = x[4],
                                 rho = x[5], K = 3)))
      }, start = c(sdetorus::toPiInt(as.numeric(ml1$mu)), sdetorus::toPiInt(as.numeric(ml2$mu)),
                   ml1$sd, ml2$sd, 0), lower = c(-pi, -pi, 0.01, 0.01, -1),
      upper = c(pi, pi, 20, 20, 1), optMethod = "Nelder-Mead")
      ```
- [ ] Recode implicit equation by first calling either `hessian_grad_mwn`, `hessian_grad_mvm`, or `hessian_grad_bwc`, internally. Then compute the projected gradient and derive the general implicit equation for the bivariate case, in a common fashion. In this way the function is easier to extend in the future to other distributions. Use `Rccp::List` to return both?
- [ ] Add full support for BWN along the package and in README.Rmd.
- [ ] Replace existent `ridge_fourier_fit` and associated functionalities with an `atan2()` fitting.

# C++

- [x] Code implicit equations in C++: `implicit_bvm` and `implicit_bwc`.
- [x] Remove auxiliary.cpp and distr.cpp once not necessary.
- [ ] Code gradient and hessian for WN, as efficiently as possible (resaving computations), together. Do it for unnormalized density. Code it for arbitrary dimension. Function: `hessian_grad_mwn`. Use `Rccp::List` in the return object.
- [ ] Same implementation for `hessian_grad_mvm` (multivariate von Mises). Do it for unnormalized density.
- [ ] Same implementation for `hessian_grad_bwc` (bivariate Wrapped Cauchy). Do it for unnormalized density.

# Other

- [x] Add Sta. Barbara dataset.
- [x] Document Sta. Barbara dataset.
- [x] Clean and add script that downloads the Sta. Barbara data.
- [x] Add script /application/data-application.R with all the analysis done for Sta. Barbara dataset.
- [x] Complete README.Rmd.
- [ ] Add unit tests to attain a coverage of 50%.
- [ ] Add unit tests to attain a coverage of 60%.
- [ ] Add unit tests to attain a coverage of 70%.
- [ ] Add unit tests to attain a coverage of 80%.
- [ ] Add unit tests to attain a coverage of 90%.
- [ ] Add unit tests to attain a coverage of ~100%.
- [ ] Check and proofread manual (close to the end).
