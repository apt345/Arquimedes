
// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::plugins("cpp11")]]
#include <RcppArmadillo.h>
#include <Rmath.h>
#include <R.h>

using namespace Rcpp;

//' @title Implicit equation of the bivariate sine von Mises ridge
//'
//' @description One of the conditions for the density ridge of a given density
//' \eqn{f} is that the modulus of its projected gradient is zero : 
//' \eqn{\mathbf{D}_{p-1}f(\mathbf{x})=0}. This function computes the LHS of
//' that implicit equation for the case of a bivariate sine von Mises density.
//' @param theta1,theta2 evaluation points.
//' @param kappa Vector with the three concentration parameters
//'  \eqn{\kappa_1, \kappa_2, \lambda}.
//' @return The value of the LHS of the implicit equation.
//' @author Arturo Prieto-Tirado.
//' @examples
//' n <- 200
//' x <- seq(-pi, pi, l = n)
//' kappa <- c(0.3, 0.4, 0.5)
//' val <- sapply(x, function(th1) implicit_bvm(theta2 = x, theta1 = th1,
//'                                             kappa = kappa))
//' val <- matrix(val, nrow = n, ncol = n)
//' old_par <- par()
//' par(mfrow = c(1,2))
//' image(x, x, -log(abs(val)), axes = FALSE, col = viridisLite::viridis(20))
//' sdetorus::torusAxis()
//' sdetorus::plotSurface2D(x, x, f = function(x) d_bvm(x = x, mu = c(0, 0),
//'                                                     kappa = kappa),
//'                         axes = FALSE)
//' sdetorus::torusAxis()
//' par(old_par)
//' @name implicit_bvm
//' @rdname implicit_bvm
//' @export
// [[Rcpp::export]]
arma::vec implicit_bvm(arma::vec theta2, double theta1, arma::vec kappa) {

  // Define constants for efficiency
  double sin1 = sin(theta1);
  double cos1 = cos(theta1);
  arma::vec sin2 = sin(theta2);
  arma::vec cos2 = cos(theta2);
  arma::vec sin12 = sin1 * sin2;

  // Gradients
  arma::vec C1 = -kappa[0] * sin1 + kappa[2] * cos1 * sin2;
  arma::vec C2 = -kappa[1] * sin2 + kappa[2] * sin1 * cos2;

  // Second derivatives
  arma::vec w_u = -kappa[1] * cos2 - kappa[2] * sin12 + kappa[0] * cos1 +
    kappa[2] * sin12 - arma::square(C1) + arma::square(C2);

  // Cross-terms
  arma::vec C5C1C2 = kappa[2] * cos1 * cos2 + C1 % C2;

  // Eigenvectors
  arma::vec rootd = sqrt(arma::square(w_u) + 4 * arma::square(C5C1C2));
  arma::vec U1 = 2 * (-w_u + C5C1C2 - rootd);
  arma::vec U2 = w_u + 4 * (C5C1C2) - rootd;

  // Normalize
  arma::vec U_norm = sqrt(arma::square(U1) + arma::square(U2));
  U1 /= U_norm;
  U2 /= U_norm;

  // Implicit ridge expression
  return(C1 % U1 + C2 % U2);

}


//' @title Implicit equation of the bivariate wrapped Cauchy ridge
//'
//' @description Computation of the value of the LHS of the implicit equation
//' for the density ridge of a bivariate wrapped Cauchy.
//' @param theta1,theta2 evaluation points.
//' @param xi1,xi2 Concentration parameters.
//' @param rho Dependence parameter.
//' @return The value of the LHS of the implicit equation.
//' @author Arturo Prieto-Tirado.
//' @examples
//' n <- 200
//' x <- seq(-pi, pi, l = n)
//' xi1 <- 0.3
//' xi2 <- 0.6
//' rho <- 0.5
//' val <- sapply(x, function(th1) implicit_bwc(theta2 = x, theta1 = th1,
//'                                           xi1 = xi1, xi2 = xi2, rho = rho))
//' val <- matrix(val, nrow = n, ncol = n)
//' old_par <- par()
//' par(mfrow = c(1,2))
//' image(x, x, -log(abs(val)), axes = FALSE, col = viridisLite::viridis(20))
//' sdetorus::torusAxis()
//' sdetorus::plotSurface2D(x, x, f = function(x) d_bwc(theta = x, xi1 = xi1,
//'                                                     xi2 = xi2, rho = rho),
//'                          axes = FALSE)
//' sdetorus::torusAxis()
//' par(old_par)
//' @name implicit_bwc
//' @rdname implicit_bwc
//' @export
// [[Rcpp::export]]
arma::vec implicit_bwc(arma::vec theta2, double theta1, double xi1, double xi2,
                       double rho) {

  // Define constants for efficiency
  double rho2 = pow(rho,2);
  double xi12 = pow(xi1,2);
  double xi22 = pow(xi2,2);
  double c0 = (1 + rho2) * (1 + xi12) * (1 + xi22) -
    8 * abs(rho) * xi1 * xi2;
  double c1 = 2 * (1 + rho2) * xi1 * (1 + xi22) -
    4 * abs(rho) * (1 + xi12) * xi2;
  double c2 = 2 * (1 + rho2) * (1 + xi12) * xi2 -
    4 * abs(rho) * xi1 * (1 + xi22);
  double c3 = -4 * (1 + rho2) * xi1 * xi2 +
    2 * abs(rho) * (1 + xi12) * (1 + xi22);
  double c4 = 2 * rho * (1 - xi12) * (1 - xi22);
  double sin1 = -sin(theta1);
  double cos1 = cos(theta1);
  arma::vec sin2 = -sin(theta2);
  arma::vec cos2 = cos(theta2);
  arma::vec sin12 = sin1 * sin2;
  arma::vec cos12 = cos1 * cos2;
  arma::vec sin1cos2 = sin1 * cos2;
  arma::vec sin2cos1 = sin2 * cos1;
  arma::vec d = c0 - c1 * cos1 - c2 * cos2 - c3 * cos12 - c4 * sin12;

  // Gradients
  arma::vec firstd1 = (c1 * sin1 + c3 * sin1cos2 - c4 * sin2cos1);
  arma::vec firstd2 = (c2 * sin2 + c3 * sin2cos1 - c4 * sin1cos2);

  // Second derivatives
  arma::vec u = 2 * (c1 * sin1 + c3 * sin1cos2 - c4 * sin2cos1) %
  (c1 * sin1 + c3 * sin1cos2 - c4 * sin2cos1) / arma::pow(d,3) +
  ( -c1 * cos1 - c3 * cos12 - c4 * sin12) / arma::square(d);
  arma::vec w = 2 * (c2 * sin2 + c3 * sin2cos1 - c4 * sin1cos2) %
    (c2 * sin2 + c3 * sin2cos1 - c4 * sin1cos2) / arma::pow(d,3)  +
        ( -c2 * cos2 - c3 * cos12 - c4 * sin12) / arma::square(d);
  arma::vec v = (c3 * sin12 + c4 * cos12) / arma::square(d) +
      2 * (c1 * sin1 + c3 * sin1cos2 - c4 * sin2cos1) %
      (c2 * sin2 + c3 * sin2cos1 - c4 * sin1cos2) / arma::pow(d,3);

  // Eigenvectors
  arma::vec G1 = 2 * (u - w + v - sqrt(arma::square(w - u) +
    4 * arma::square(v)));
  arma::vec G2 = w - u + 4 * v - sqrt(arma::square(w - u) +
    4 * arma::square(v));

  // Normalize
  arma::vec G_norm = sqrt(arma::square(G1) + arma::square(G2));
  G1 /= G_norm;
  G2 /= G_norm;

  // Implicit ridge expression
  return(firstd1 % G1 + firstd2 % G2);

}