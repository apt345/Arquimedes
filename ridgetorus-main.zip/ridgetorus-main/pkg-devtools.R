
library(devtools)
library(covr)
library(lintr)

# Set wd
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
setwd("../")

# Package name
pkg_name <- "ridgetorus"

# Load package
load_all(path = pkg_name)

# Documentation
document(pkg = pkg_name)

# Tests
test(pkg = pkg_name)

# lintr -- highlight bad practices
lint_package(pkg_name)

# Run examples
run_examples(pkg_name, run_dontrun = TRUE, run_donttest = TRUE, fresh = TRUE)

# Check
check(pkg = pkg_name, cran = TRUE)

# Check spelling
spell_check(pkg = pkg_name)

# Tests coverage
(covr_pkg <- package_coverage(path = pkg_name))
report(covr_pkg)

# Build
build(pkg_name, vignettes = FALSE)

# Install locally
install(pkg_name, args = c("--no-multiarch", "--no-test-load"),
        build_vignettes = FALSE)
packageVersion(pkg_name)

# Build pdf
path <- find.package(pkg_name)
file.remove(paste0(pkg_name, ".pdf"))
system(paste(shQuote(file.path(R.home("bin"), "R")),
             "CMD", "Rd2pdf", shQuote(path)))
build_manual(pkg_name)

# # Checks by release()
# setwd(pkg_name)
# check_rhub(pkg = ".", interactive = FALSE,
#            check_args = "--as-cran", env_vars = c(`_R_CHECK_FORCE_SUGGESTS_` = "true",
#                                                   `_R_CHECK_DONTTEST_EXAMPLES_` = "false"))
# check_win_devel(pkg =  ".")
# spell_check(pkg = ".")
# release(".")
